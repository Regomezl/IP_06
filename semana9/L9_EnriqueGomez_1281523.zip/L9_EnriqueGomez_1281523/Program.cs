﻿class Program
{
    static void Main()
    {
        Console.Write("Ingrese el monto de la compra en Q: ");
        string montoInicial = Console.ReadLine();

        if (montoInicial == null || montoInicial == "")
        {
            Console.WriteLine("Error: Debe ingresar un monto válido.");
        }
        else
        {
            if (decimal.TryParse(montoInicial, out decimal monto))
            {
                decimal descuento = 0;

                switch (monto)
                {
                    case decimal _ when monto < 400:
                        descuento = 0;
                        break;
                    case decimal _ when monto <= 1000:
                        descuento = monto * 0.07m;
                        break;
                    case decimal _ when monto <= 5000:
                        descuento = monto * 0.10m;
                        break;
                    case decimal _ when monto <= 15000:
                        descuento = monto * 0.15m;
                        break;
                    default:
                        descuento = monto * 0.25m;
                        break;
                }

                Console.Write("¿Tiene un código de descuento? (Si/N0): ");
                string respuesta = Console.ReadLine();

                if (respuesta == "Si" || respuesta == "no")
                {
                    descuento += monto * 0.05m;
                }

                decimal montoFinal = monto - descuento;

                Console.WriteLine($"Monto a pagar final: Q{montoFinal}");
            }
            else
            {
                Console.WriteLine("Error: Ingrese un monto válido en números.");
            }
        }
    }
}