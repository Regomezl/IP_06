﻿Console.WriteLine("Ejercicio 1");

int numero;
bool entradaValida = false;

do
{
    Console.Write("Número ENTERO: ");
    string input = Console.ReadLine();

    if (int.TryParse(input, out numero))
    {
        entradaValida = true;
    }
    else
    {
        Console.WriteLine("Entrada no válida. Por favor, ingrese un número entero.");
    }
} while (!entradaValida);

string resultado = "";

if (numero > 0)
{
    resultado = "positivo";
}
else if (numero < 0)
{
    resultado = "negativo";
}
else
{
    resultado = "cero";
}

Console.WriteLine($"RESULTADO: El número ingresado es {resultado}.");

Console.ReadLine();


