﻿using System;

class Program
{ 
static void Main(string[] args)
{
        Console.WriteLine("Ingrese su nombre: ");
        String Nombre = Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("Soy" + Nombre);

        /* COMENTARIOS*/
        Console.Write("Hola Mundo");
        Console.Write("Soy" + Nombre);
        Console.ReadKey();
    }
}
